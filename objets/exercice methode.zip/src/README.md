Afficher dans la console le jour et l'heure du moment

```
VARIABLES

String jour;

String heure;

afficherJourEtHeure

String retour
```